const express = require('express');
const mysql = require('mysql2');
const app = express();
const port = 3000;
const bodyParser=require('body-parser')
const path= require('path')
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, 'login.html')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'your_password',
    database: 'user'
});


db.connect(err => {
    if (err) {
        throw err;
    }
    console.log('MySQL connected...');
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});